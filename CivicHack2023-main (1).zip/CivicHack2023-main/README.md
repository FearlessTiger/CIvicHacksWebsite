# CivicHack2023
A website which allows you to view information about pharmaceutical drugs
	¯\_(ツ)_/¯
